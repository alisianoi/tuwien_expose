################################################################################
#
# README for writing an exposé in LaTeX 
#
################################################################################

Use this template to write an exposé for a thesis or project carried out at INSO.

For general help about using the templates and for help with LaTeX, please consult 
the top-level README.txt file.

#===============================================================================
#==	LaTex Notes
#===============================================================================

Options:
--------------------------------------------------------------------------------

english, german, ngerman: 
		Language settings

public: 
		When public is set, then estimated pages will not be shown in the expose.
		This option should be disabled for internal use and enabled in the final 
		version of the expose.
